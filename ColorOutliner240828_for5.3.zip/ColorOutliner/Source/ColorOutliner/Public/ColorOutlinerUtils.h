// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#pragma once
#include "Kismet/KismetStringLibrary.h"

struct FActorFolderTreeItem;
struct FActorTreeItem;

/*Debug macros*/
#if 0
#define DoubleToString UKismetStringLibrary::Conv_DoubleToString

#define Sleep(Frame) std::this_thread::sleep_for(std::chrono::milliseconds(Frame))

#define NewThread(Execute) std::thread([&]() {Execute}).detach()
#endif

/*Debug functions*/
#if 0
namespace Debug
{
	static void Print(const FString& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message);
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*message);
	}
	static void Print(const int32& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, FString::FromInt(message));
		}
		UE_LOG(LogTemp,Warning,TEXT("%i"),message);
	}
	static void Print(const double& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, UKismetStringLibrary::Conv_DoubleToString(message));
		}
		UE_LOG(LogTemp,Warning,TEXT("%f"),message);
	}
	static void Print(const FText& message, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, message.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*message.ToString());
	}
	static void Print(const FVector& InVector, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, InVector.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*InVector.ToString());
	}
	static void Print(const FRotator& InRotator, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, InRotator.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*InRotator.ToString());
	}
	static void Print(const FLinearColor& InColor, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, InColor.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*InColor.ToString());
	}
	static void Print(const FVector3f& InVector, FColor color = FColor::Blue)
	{
		if (GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1, 3, color, InVector.ToString());
		}
		UE_LOG(LogTemp,Warning,TEXT("%s"),*InVector.ToString());
	}
	static void FastPrint()
	{
		Print(TEXT("FastPring : Debug"));
		UE_LOG(LogTemp,Warning,TEXT("FastPring : Debug"));
	}
}
#endif

/*Utility*/
namespace SceneOutlinerFolderUtils
{
	FLinearColor GetOutlinerItemDefaultColor(const bool bIsFolder);

	FString GetSectionName();
	
	FName GetDefaultContextBaseMenuName();

	/*Append current map path with inFolder's path / inActor's guid*/
	FString GetFolderFullPath(const FActorFolderTreeItem* SelectedFolder);
	FString GetFolderFullPath(const FFolder& Folder);
	
	FString GetActorFullPath(const FActorTreeItem* SelectedActor);
	FString GetActorFullPath(const AActor* InActor);

	bool IsActorInTempMap(const FString& ActorFullPath);
	
	/*Input path,Find color from config INI*/
	TOptional<FLinearColor> GetColorByPath(const FString& InFullPath, const bool bIsFolder);
	TOptional<FLinearColor> GetColorByPathTemp(const FString& InTempPath);
	
	/*OnColorClicked, save in config*/
	void SaveColorWithPath(const FString& InFullPath, TOptional<FLinearColor> InColor,bool bIsFolder);
	void SaveColorWithPathTemp(const FString& InTempPath, TOptional<FLinearColor> InColor, const bool bIsFolder);
	
	/*OnRowConstruct*/
	void SetIconColor(TSharedPtr<SWidget> RowWidget,const FLinearColor InColor);
	void SetTextColor(TSharedPtr<SWidget> HorizontalBox,const FLinearColor InColor);
	
	/*On Tear Down World*/
	void ClearColorsTemp();

	/*On Temp map save as a map asset ,Take temp TMap property to config */
	void TempToSave(const UWorld* World);

	/*MapRename Event */
	/*OnPreWorldRename , save its old name , when renamed , find old name in config and replace its*/
	void OnPreWorldRename(UWorld* World);
	/*OnPostWorldRename ,  find old name in config and replace its*/
	void OnPostWorldRename(UWorld* World);

	/*MapDelete Event*/
	/*OnAssetsPreDelete , save its path , when deleted , find path in config and clear it.*/
	void OnWorldPreDelete(const TArray<UObject*>& Objects);
	/*OnAssetsDeleted, find path in config and clear it. (assets was deleted, no path data , should save them before delete*/
	void OnWorldDeleted();

	/*FolderOperate Event*/
	/*OnFolderMoved , update path in config*/
	void UpdateFolderFullPath(const FFolder& Source, const FFolder& Dest);
	/*OnFolderDeleted, delete path in config*/
	void DeleteFolderFullPath(const FFolder& Folder);

	/*OnActorDeleted, delete path in config*/
	void DeleteActorFullPath(const AActor* InActor);
	
	/*When open map,check it if temp map, save it bool*/
	void SaveIsTempMap(const bool IsTemp);
	/*Is current map temp? */
	bool GetIsTempMap();

	/*On LoadMap , Save current map's asset path to a FString*/
	void SaveCurrentMapPath(const FString& InMapPath);
	/*return now map's asset path*/
	FString GetCurrentMapPath();

	void SaveIsFolderMoved(const bool IsMoved);
	bool GetIsFolderMoved();

	void SaveIsCurrentMapRenamed(const bool bInIsCurrentMap);
	bool GetIsCurrentMapRenamed();
	
	/*OnClearColor*/
	void DeleteFullPathFromConfig(const FString& InPath);
	/*OnClearColor _ In temp map*/
	void DeleteFullPathFromTemp(const FString& InPath);
	
	/*On Shutdown*/
	void ClearCache();
}
