﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "ColorOutlinerSettings.h"
//#include "Delegates/DelegateCombinations.h"

#define LOCTEXT_NAMESPACE "FColorOutlinerModule"

PRAGMA_DISABLE_DEPRECATION_WARNINGS

FColorOutlinerSettingsDelegates::FOnPostEditChangeProperty  FColorOutlinerSettingsDelegates::OnPostEditChangeProperty;

PRAGMA_ENABLE_DEPRECATION_WARNINGS

FName UColorOutlinerSettings::GetCategoryName() const
{
	return TEXT("Plugins");
}

#if WITH_EDITOR
FText UColorOutlinerSettings::GetSectionText() const
{
	return LOCTEXT("ColorOutlinerSettings", "Color Outliner");
}

FName UColorOutlinerSettings::GetSectionName() const
{
	return TEXT("Color Outliner");
}

FText UColorOutlinerSettings::GetSectionDescription() const
{
	return FText::FromString(TEXT("The following settings are not mandatory, please adjust them according to your preference."));
}

void UColorOutlinerSettings::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	//SNavigationManagerWidget::UpdateDPIScaling(this);
	FColorOutlinerSettingsDelegates::OnPostEditChangeProperty.Broadcast();
}
#endif